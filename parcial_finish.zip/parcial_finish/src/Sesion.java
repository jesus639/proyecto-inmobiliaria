
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class Sesion {
    public static String usuario;
    public static String contraseña;
    public static String rol;
    public static String correo;
    public static String nombreCompleto;
    public static String rutaImagenSeleccionada;
    public static ArrayList<String> rutasImagenes = new ArrayList<>();
    
}
