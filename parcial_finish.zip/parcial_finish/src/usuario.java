/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class usuario {
        protected String nombre;
    protected String correo;
    protected String telefono;
    protected String cedula;
    
    //Constructor
    public usuario(String nombre, String correo, String telefono, String cedula){
        this.nombre = nombre;
        this.correo = correo;
        this.telefono = telefono;
        this.cedula = cedula;
    }

}
