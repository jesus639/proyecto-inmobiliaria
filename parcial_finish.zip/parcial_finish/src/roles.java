/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class roles {
    public static final String[] Tipousuario = {"Cliente","Agente","Administrador","Propietario"};
    
                public String[] getCargo() {
        return this.Tipousuario;
        }
    
    
}

