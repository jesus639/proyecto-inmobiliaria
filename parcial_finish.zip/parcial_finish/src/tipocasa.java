/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class tipocasa {
                   private String[] cargos = {"seleccione..","casa","apartamento","proyecto","local"};
        private String obtenerCar;
        
        public void setCargo(String cargo) {
        this.obtenerCar= cargo;
    }
        public String[] getCargo() {
        return this.cargos;
        }
        }
